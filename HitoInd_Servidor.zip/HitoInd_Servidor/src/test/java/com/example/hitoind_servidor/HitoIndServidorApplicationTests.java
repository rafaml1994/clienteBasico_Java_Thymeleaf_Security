package com.example.hitoind_servidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HitoIndServidorApplicationTests {

    @Test
    void contextLoads() {
    }

}
