package com.example.hitoind_servidor.repositories;

import com.example.hitoind_servidor.models.Usuarios;
import org.springframework.data.jpa.repository.JpaRepository;



public interface UsuarioRepositorio extends JpaRepository<Usuarios,String> {
}
