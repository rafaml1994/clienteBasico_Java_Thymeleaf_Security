package com.example.hitoind_servidor.repositories;


import com.example.hitoind_servidor.models.Usuarios;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.ApplicationScope;

import java.util.List;

@Service
@ApplicationScope
public class UsuarioService {
    private UsuarioRepositorio usuario;

    public UsuarioRepositorio getUsuario() {
        return usuario;
    }

    public UsuarioService(UsuarioRepositorio usuario) {
        this.usuario = usuario;
    }

    public List<Usuarios> allUsuarios(){
        return usuario.findAll();
    }
}
