package com.example.hitoind_servidor.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class MedicosController {

}
