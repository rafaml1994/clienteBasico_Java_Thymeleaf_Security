package com.example.hitoind_servidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HitoIndServidorApplication {

    public static void main(String[] args) {
        SpringApplication.run(HitoIndServidorApplication.class, args);
    }

}
